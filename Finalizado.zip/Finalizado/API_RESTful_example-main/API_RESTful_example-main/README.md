# API RESTful
Ejemplo de una API RESTful básico para iniciar un proyecto.

## Prerequisitos
- Java JDK 21
- Spring Boot 3.3.1
- MySql 8