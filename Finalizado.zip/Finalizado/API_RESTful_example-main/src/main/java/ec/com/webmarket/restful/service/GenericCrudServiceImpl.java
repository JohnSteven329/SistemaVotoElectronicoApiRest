package ec.com.webmarket.restful.service;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Example;
import org.springframework.data.domain.ExampleMatcher;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Service;
import ec.com.webmarket.restful.common.ApiException;

@Service
public abstract class GenericCrudServiceImpl<DOMAIN, DTO> implements GenericCrudService<DOMAIN, DTO> {

    @Autowired
    public abstract JpaRepository<DOMAIN, Long> getRepository();

    @Override
    public DTO create(DTO dto) {
        DOMAIN domainObject = mapToDomain(dto);
        if (getRepository().exists(Example.of(domainObject, ExampleMatcher.matchingAny()))) {
            throw new ApiException("Record already exists");
        }
        DOMAIN created = getRepository().save(domainObject);
        return mapToDto(created);
    }

    @Override
    public DTO update(DTO dto) {
        DOMAIN domainObject = mapToDomain(dto);
        if (!getRepository().existsById(getId(dto))) {
            throw new ApiException("Record not found");
        }
        DOMAIN updated = getRepository().save(domainObject);
        return mapToDto(updated);
    }

    @Override
    public void delete(Long id) {
        getRepository().deleteById(id);
    }

    @Override
    public Optional<DTO> find(DTO dto) {
        DOMAIN domainObject = mapToDomain(dto);
        return getRepository().findOne(Example.of(domainObject)).map(this::mapToDto);
    }

    @Override
    public List<DTO> findAll(DTO dto) {
        DOMAIN domainObject = mapToDomain(dto);
        List<DOMAIN> list = getRepository().findAll(Example.of(domainObject));
        return list.stream().map(this::mapToDto).collect(Collectors.toList());
    }

    public abstract DOMAIN mapToDomain(DTO dto);

    public abstract DTO mapToDto(DOMAIN domain);

    public abstract Long getId(DTO dto);
}
