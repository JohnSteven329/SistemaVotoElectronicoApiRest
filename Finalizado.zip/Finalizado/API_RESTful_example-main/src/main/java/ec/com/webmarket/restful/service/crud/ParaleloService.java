package ec.com.webmarket.restful.service.crud;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Service;
import ec.com.webmarket.restful.domain.Paralelo;
import ec.com.webmarket.restful.dto.v1.ParaleloDTO;
import ec.com.webmarket.restful.persistence.ParaleloRepository;
import ec.com.webmarket.restful.service.GenericCrudServiceImpl;

@Service
public class ParaleloService extends GenericCrudServiceImpl<Paralelo, ParaleloDTO> {

    @Autowired
    private ParaleloRepository repository;

    private ModelMapper modelMapper = new ModelMapper();

    @Override
    public Paralelo mapToDomain(ParaleloDTO dto) {
        return modelMapper.map(dto, Paralelo.class);
    }

    @Override
    public ParaleloDTO mapToDto(Paralelo domain) {
        return modelMapper.map(domain, ParaleloDTO.class);
    }

    @Override
    public Long getId(ParaleloDTO dto) {
        return dto.getId();
    }

    @Override
    public JpaRepository<Paralelo, Long> getRepository() {
        return repository;
    }
}
