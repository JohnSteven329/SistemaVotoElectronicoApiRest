package ec.com.webmarket.restful.api.v1;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import ec.com.webmarket.restful.common.ApiConstants;
import ec.com.webmarket.restful.dto.v1.ParaleloDTO;
import ec.com.webmarket.restful.security.ApiResponseDTO;
import ec.com.webmarket.restful.service.crud.ParaleloService;
import jakarta.validation.Valid;

@RestController
@RequestMapping(ApiConstants.URI_API_V1_PARALELOS)
public class ParaleloController {

    @Autowired
    private ParaleloService paraleloService;

    @GetMapping
    public ResponseEntity<?> getAll() {
        return ResponseEntity.ok(new ApiResponseDTO<>(true, paraleloService.findAll(new ParaleloDTO())));
    }

    @PostMapping
    public ResponseEntity<?> create(@Valid @RequestBody ParaleloDTO dto) {
        return ResponseEntity.status(HttpStatus.CREATED).body(new ApiResponseDTO<>(true, paraleloService.create(dto)));
    }

    @PutMapping
    public ResponseEntity<?> update(@Valid @RequestBody ParaleloDTO dto) {
        return ResponseEntity.ok(new ApiResponseDTO<>(true, paraleloService.update(dto)));
    }

    @GetMapping("/{id}")
    public ResponseEntity<?> getById(@Valid @PathVariable Long id) {
        ParaleloDTO dto = new ParaleloDTO();
        dto.setId(id);
        return ResponseEntity.ok(new ApiResponseDTO<>(true, paraleloService.find(dto)));
    }
}



