package ec.com.webmarket.restful.service.crud;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Service;
import ec.com.webmarket.restful.domain.Curso;
import ec.com.webmarket.restful.domain.Estudiante;
import ec.com.webmarket.restful.domain.Paralelo;
import ec.com.webmarket.restful.dto.v1.EstudianteDTO;
import ec.com.webmarket.restful.persistence.EstudianteRepository;
import ec.com.webmarket.restful.service.GenericCrudServiceImpl;

import java.util.List;

@Service
public class EstudianteService extends GenericCrudServiceImpl<Estudiante, EstudianteDTO> {

    @Autowired
    private EstudianteRepository repository;

    private ModelMapper modelMapper = new ModelMapper();

    @Override
    public Estudiante mapToDomain(EstudianteDTO dto) {
        return modelMapper.map(dto, Estudiante.class);
    }

    @Override
    public EstudianteDTO mapToDto(Estudiante domain) {
        return modelMapper.map(domain, EstudianteDTO.class);
    }

    @Override
    public Long getId(EstudianteDTO dto) {
        return dto.getId();
    }

    @Override
    public JpaRepository<Estudiante, Long> getRepository() {
        return repository;
    }

    public List<Estudiante> findByCurso(Long id) {
        Curso curso = new Curso();
        curso.setId(id);
        return repository.findByCurso(curso);
    }

    public List<Estudiante> findByParalelo(Long id) {
        Paralelo paralelo = new Paralelo();
        paralelo.setId(id);
        return repository.findByParalelo(paralelo);
    }
}

	


