package ec.com.webmarket.restful;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ApiResTfulExampleApplication {
    public static void main(String[] args) {
        SpringApplication.run(ApiResTfulExampleApplication.class, args);
    }
}
