package ec.com.webmarket.restful.service.crud;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Service;
import ec.com.webmarket.restful.domain.Candidato;
import ec.com.webmarket.restful.dto.v1.CandidatoDTO;
import ec.com.webmarket.restful.persistence.CandidatoRepository;
import ec.com.webmarket.restful.service.GenericCrudServiceImpl;

@Service
public class CandidatoService extends GenericCrudServiceImpl<Candidato, CandidatoDTO> {

    @Autowired
    private CandidatoRepository repository;

    private ModelMapper modelMapper = new ModelMapper();

    @Override
    public Candidato mapToDomain(CandidatoDTO dto) {
        return modelMapper.map(dto, Candidato.class);
    }

    @Override
    public CandidatoDTO mapToDto(Candidato domain) {
        return modelMapper.map(domain, CandidatoDTO.class);
    }

    @Override
    public Long getId(CandidatoDTO dto) {
        return dto.getId();
    }

    @Override
    public JpaRepository<Candidato, Long> getRepository() {
        return repository;
    }
}


