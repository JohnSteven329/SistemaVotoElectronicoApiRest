package ec.com.webmarket.restful.api.v1;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import ec.com.webmarket.restful.common.ApiConstants;
import ec.com.webmarket.restful.dto.v1.CursoDTO;
import ec.com.webmarket.restful.security.ApiResponseDTO;
import ec.com.webmarket.restful.service.crud.CursoService;
import jakarta.validation.Valid;

@RestController
@RequestMapping(ApiConstants.URI_API_V1_CURSOS)
public class CursoController {

    @Autowired
    private CursoService cursoService;

    @GetMapping
    public ResponseEntity<?> getAll() {
        return ResponseEntity.ok(new ApiResponseDTO<>(true, cursoService.findAll(new CursoDTO())));
    }

    @PostMapping
    public ResponseEntity<?> create(@Valid @RequestBody CursoDTO dto) {
        return ResponseEntity.status(HttpStatus.CREATED).body(new ApiResponseDTO<>(true, cursoService.create(dto)));
    }

    @PutMapping
    public ResponseEntity<?> update(@Valid @RequestBody CursoDTO dto) {
        return ResponseEntity.ok(new ApiResponseDTO<>(true, cursoService.update(dto)));
    }

    @GetMapping("/{id}")
    public ResponseEntity<?> getById(@Valid @PathVariable Long id) {
        CursoDTO dto = new CursoDTO();
        dto.setId(id);
        return ResponseEntity.ok(new ApiResponseDTO<>(true, cursoService.find(dto)));
    }
}


