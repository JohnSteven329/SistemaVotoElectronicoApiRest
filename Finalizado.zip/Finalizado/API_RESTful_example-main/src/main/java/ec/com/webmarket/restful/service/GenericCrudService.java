package ec.com.webmarket.restful.service;

import java.util.List;
import java.util.Optional;

public interface GenericCrudService<DOMAIN, DTO> {

    DTO create(DTO dto);

    DTO update(DTO dto);

    void delete(Long id);

    List<DTO> findAll(DTO dto);

    Optional<DTO> find(DTO dto);

    DOMAIN mapToDomain(DTO dto);

    DTO mapToDto(DOMAIN domain);

    Long getId(DTO dto);
}
