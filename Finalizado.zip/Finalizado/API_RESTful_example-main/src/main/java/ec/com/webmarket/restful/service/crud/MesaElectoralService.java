package ec.com.webmarket.restful.service.crud;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Service;
import ec.com.webmarket.restful.domain.MesaElectoral;
import ec.com.webmarket.restful.dto.v1.MesaElectoralDTO;
import ec.com.webmarket.restful.persistence.MesaElectoralRepository;
import ec.com.webmarket.restful.service.GenericCrudServiceImpl;

@Service
public class MesaElectoralService extends GenericCrudServiceImpl<MesaElectoral, MesaElectoralDTO> {

    @Autowired
    private MesaElectoralRepository repository;

    private ModelMapper modelMapper = new ModelMapper();

    @Override
    public MesaElectoral mapToDomain(MesaElectoralDTO dto) {
        return modelMapper.map(dto, MesaElectoral.class);
    }

    @Override
    public MesaElectoralDTO mapToDto(MesaElectoral domain) {
        return modelMapper.map(domain, MesaElectoralDTO.class);
    }

    @Override
    public Long getId(MesaElectoralDTO dto) {
        return dto.getId();
    }

    @Override
    public JpaRepository<MesaElectoral, Long> getRepository() {
        return repository;
    
}
    }


