package ec.com.webmarket.restful.service.crud;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Service;
import ec.com.webmarket.restful.domain.Voto;
import ec.com.webmarket.restful.dto.v1.VotoDTO;
import ec.com.webmarket.restful.persistence.VotoRepository;
import ec.com.webmarket.restful.service.GenericCrudServiceImpl;

@Service
public class VotoService extends GenericCrudServiceImpl<Voto, VotoDTO> {

    @Autowired
    private VotoRepository repository;

    private ModelMapper modelMapper = new ModelMapper();

    @Override
    public Voto mapToDomain(VotoDTO dto) {
        return modelMapper.map(dto, Voto.class);
    }

    @Override
    public VotoDTO mapToDto(Voto domain) {
        return modelMapper.map(domain, VotoDTO.class);
    }

    @Override
    public Long getId(VotoDTO dto) {
        return dto.getId();
    }

    @Override
    public JpaRepository<Voto, Long> getRepository() {
        return repository;
    }
}


